package com.cg.treeset;

import java.util.TreeSet;

public class SortProducts 
{
	public static void main(String[] args) 
	{
		TreeSet<String> ts=new TreeSet<>();
		ts.add("pen");
		ts.add("pencil");
		ts.add("marker");
		System.out.println(ts);
		
		TreeSet<Integer> ts2=new TreeSet<>();
		ts2.add(12);
		ts2.add(9);
		ts2.add(8);
		ts2.add(12);
		System.out.println(ts2);
		
		TreeSet<Product> tsp=new TreeSet<>(new NameBasedComparator());
		Product p1=new Product();
		p1.setId(1);;
		p1.setName("pen");
		p1.setPrice(25.00);
		tsp.add(p1);
		
		Product p2=new Product();
		p2.setId(2);;
		p2.setName("marker");
		p2.setPrice(50.00);
		tsp.add(p2);
		
		System.out.println(tsp);
	}
}
