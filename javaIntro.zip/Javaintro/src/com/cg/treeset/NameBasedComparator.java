package com.cg.treeset;

import java.util.Comparator;

public class NameBasedComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Product p1=(Product)o1;
		Product p2=(Product)o2;
		String s1=p1.getName();
		String s2=p2.getName();
		if(s1.compareTo(s2)>0)
			return 1;
		else if(s1.compareTo(s2)<0)
			return -1;
		else 
			return 0;
	
	}

}
