package com.cg.hashset;

import java.util.HashSet;

public class TestCar {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		HashSet<Car> hs=new HashSet<>();
		Car c1=new Car();
		c1.setModel("alto 800");
		c1.setColor("red");
		hs.add(c1);
		
		Car c2=new Car();
		c2.setModel("alto 800");
		c2.setColor("red");
		hs.add(c2);
		
		System.out.println(hs);
		
		HashSet<String> h1=new HashSet<>();
		h1.add("java");
		h1.add("pega");
		h1.add("java");
		System.out.println(h1                                                                                                                                                                                            );
		
		HashSet<Integer> h2=new HashSet<>();
		h2.add(23);
		h2.add(19);
		h2.add(23);
		
		
		System.out.println(h2);
	}

}
