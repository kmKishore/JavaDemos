package com.cg.javainterface;

public class BillClass implements BillInterface {

	@Override
	public void billing() {
		// TODO Auto-generated method stub

	}

	@Override
	public void discount() {
		// TODO Auto-generated method stub

	}

}
