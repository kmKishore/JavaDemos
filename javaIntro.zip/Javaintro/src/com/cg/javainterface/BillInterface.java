package com.cg.javainterface;

public interface BillInterface {
		
	void billing();
	void discount();
}
