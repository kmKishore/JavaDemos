package com.cg.dateAPI;

import java.time.LocalDate;
import java.time.Period;

public class Date1 {

		private LocalDate dob;
		
		public static void main(String args[])
		{
			Date1 d1=new Date1();
			LocalDate today=LocalDate.now();
			System.out.println(today.getYear());
			System.out.println(today.getMonth());
			System.out.println(today.getDayOfMonth());
			
			Date1 d2=new Date1();
			d2.dob=LocalDate.of(1997, 01, 13);
			
			Period p=Period.between(d1.dob, today);
			System.out.println(p.getYears());
			System.out.println(p.getMonths());
			System.out.println(p.getDays());
		}
}
