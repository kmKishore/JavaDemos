package com.cg.map;

public class Practice {
//number n1= new Integer(arg0);
	
}
