package com.cg.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo 
{
	public static void main(String[] args) {
		
		HashMap<Integer, String> hm=new HashMap<>();
		hm.put(1, "jan");
		hm.put(2,"Feb");
		hm.put(3,"March");
		System.out.println(hm);
		
		Set<Integer> s=hm.keySet();
	//	Set<Entry<Integer, String>> s1=hm.entrySet();
		
		Iterator<Integer> it=s.iterator();
		while(it.hasNext()) {
				int i=it.next();
				System.out.println(i + " " + hm.get(i));
		}
	}
}
