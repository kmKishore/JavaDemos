package com.cg.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class MonthDay {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		HashMap<String,Integer> hm=new HashMap<>();
		hm.put("jan",31);
		hm.put("feb",28);
		hm.put("march",31);
		hm.put("april",30);
		hm.put("may",31);
		System.out.println(hm);
		
		Scanner sc=new Scanner(System.in);
		String mon=sc.next();
		String mon2=mon.toLowerCase();
		System.out.println(hm.get(mon2));
		 
		

	}

}
