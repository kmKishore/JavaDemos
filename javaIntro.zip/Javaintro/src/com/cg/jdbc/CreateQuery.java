package com.cg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateQuery {
	public static void main(String[] args) throws ClassNotFoundException,SQLException
	{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");//Step 1
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String pass="Capgemini123";
		
		//step 2
		Connection con=DriverManager.getConnection(url, user, pass);
		
		//Step 3
		Statement st=con.createStatement(); 
		//step 4
		String sql="create table customer1(cid int,cname varchar(30))";
		st.executeQuery(sql);
		System.out.println("table created");
		//Step 5
		
		
		//step 6
		con.close();
	}
}
