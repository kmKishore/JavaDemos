package com.cg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertQueryloop {
	public static void main(String[] args) throws ClassNotFoundException,SQLException
	{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");//Step 1
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String pass="Capgemini123";
		
		//step 2
		Connection con=DriverManager.getConnection(url, user, pass);
		
		//Step 3
		PreparedStatement ps=con.prepareStatement("insert into customer1 values(?,?)"); 
		
		//step 4
		int a=0;
		do
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id ");
		int id=sc.nextInt();
		System.out.println("enter name ");
		String name =sc.next();
		
		ps.setInt(1, id);
		ps.setString(2, name);
		
		ps.executeUpdate();
		System.out.println("record inserted");
		
		System.out.println("enter 1 to continue inserting");
		a=sc.nextInt();
		}while(a==1);
		//Step 5

		
		//step 6
		con.close();
	}
}