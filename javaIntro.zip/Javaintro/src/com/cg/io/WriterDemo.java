package com.cg.io;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class WriterDemo {

	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		FileWriter fos=new FileWriter("test2.txt",true);
		String s="Hello bhai ";
	
		fos.write(s);
		System.out.println("success");
		fos.close();
	}

}
