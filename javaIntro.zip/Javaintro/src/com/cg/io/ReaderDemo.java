package com.cg.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReaderDemo {

	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				FileReader fis=new FileReader("test2.txt");
				int ch;
				while((ch=fis.read())!=-1)
				{
					System.out.print((char)ch);
				}

					
	}

}
