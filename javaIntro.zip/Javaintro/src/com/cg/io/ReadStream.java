package com.cg.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadStream {

	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		FileInputStream fis=new FileInputStream("test.txt");
		int ch;
		while((ch=fis.read())!=-1)
		{
			System.out.print((char)ch);
		}

	}

}
