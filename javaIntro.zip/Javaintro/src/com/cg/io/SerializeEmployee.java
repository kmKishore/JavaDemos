package com.cg.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializeEmployee {

	public static void main(String[] args) throws IOException 
	{
		// TODO Auto-generated method stub
		FileOutputStream fos=new FileOutputStream("emp.txt");
		ObjectOutputStream os=new ObjectOutputStream(fos);
		Employee e=new Employee();
		e.setId(123);
		e.setName("newton");
		e.setSalary(21000);
		e.setDes("scientist");
		os.writeObject(e);;
		System.out.println("success");
		os.close();
		fos.close();
	}

}
