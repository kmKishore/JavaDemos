package com.cg.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteStream {

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		FileOutputStream fos=new FileOutputStream("test.txt",true);
		String s="Hey bro ";
		byte[] b=s.getBytes();
		fos.write(b);
		System.out.println("success");
		fos.close();
		
	}

}
