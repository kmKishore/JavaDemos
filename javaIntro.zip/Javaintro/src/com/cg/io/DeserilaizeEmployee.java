package com.cg.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserilaizeEmployee 
{
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		FileInputStream fis=new FileInputStream("emp.txt");
		ObjectInputStream os=new ObjectInputStream(fis);
		Employee e=(Employee)os.readObject();
		System.out.println(e);
		os.close();
		fis.close();
	}
}
