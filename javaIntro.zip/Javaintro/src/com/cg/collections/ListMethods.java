package com.cg.collections;

import java.util.ArrayList;
import java.util.List;

public class ListMethods {

	public static void main(String[] args) {
		
		List<Integer> list=new ArrayList<>();
		for(int i=10;i<=100;i=i+10)
		{
			list.add(i);
			
		}
		System.out.println("list "+list);
		list.add(2,100);
		System.out.println("after insert " + list);
		list.set(3, 200);
		System.out.println("After replace "+ list);
		List<Integer> secondList =new ArrayList<>();
		secondList.add(111);
		secondList.add(111);
		secondList.add(111);
		list.addAll(4,secondList);
		System.out.println("After insert od second list "+ list);
		if(list.contains(111))
			System.out.println("List ha the val");
		else
			System.out.println("list do not have ");
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i));
		}
		list.remove(3);
		System.out.println(list);
	}
}
