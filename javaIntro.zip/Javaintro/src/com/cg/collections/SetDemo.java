package com.cg.collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random obj=new Random();
		HashSet<Integer> set=new HashSet<>();
		LinkedHashSet<Integer> set2=new LinkedHashSet<>();
		Set<Integer> set3=new TreeSet<>();
		
		for(int i=1;i<=5;i++)
		{
			int num=obj.nextInt(20);
			set.add(num);
			set2.add(num);
			set3.add(num);
			System.out.println(num);
		}
		
		System.out.println("Hashset" +  set);
		System.out.println("LinkedHashset" +  set2);
		System.out.println("Treeset" +  set3);
		
	}

}
