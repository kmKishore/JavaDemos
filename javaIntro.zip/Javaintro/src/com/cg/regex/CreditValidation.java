package com.cg.regex;

import java.util.Scanner;

public class CreditValidation {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String username=sc.next();
		String regEx="[4-5][0-9]{15}";
		if(username.matches(regEx))
		{
			if(username.charAt(0)=='4')
			{
				System.out.println("Visa");
			}
			else
				System.out.println("mastercard");
		}
		else
			System.out.println("not valid");
	}
}
