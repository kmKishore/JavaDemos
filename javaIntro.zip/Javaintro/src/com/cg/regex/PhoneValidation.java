package com.cg.regex;

import java.util.Scanner;

public class PhoneValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String username=sc.next();
		String regEx="(91|0)?[6-9][0-9]{9}";
		if(username.matches(regEx))
		{
			System.out.println("valid");
		}
		else
			System.out.println("not valid");

	}

}
