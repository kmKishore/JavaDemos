package com.cg.regex;

import java.util.Scanner;

public class UsernameValidation 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String username=sc.next();
		String regEx="[a-zA-Z0-9]{4,12}";
		if(username.matches(regEx))
		{
			System.out.println("valid");
		}
		else
			System.out.println("not valid");
	}
}
