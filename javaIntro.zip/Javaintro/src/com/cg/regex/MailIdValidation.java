package com.cg.regex;

import java.util.Scanner;

public class MailIdValidation {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String username=sc.next();
		String regEx="[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+";
		if(username.matches(regEx))
		{
			System.out.println("valid");
		}
		else
			System.out.println("not valid");
	}
}


