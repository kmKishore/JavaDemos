package com.cg.javaexceptions;

import java.util.Scanner;

public class TextEx2 {

	public static void main(String[] args) //throws Exception
	{
		// TODO Auto-generated method stub
		int a=10;
		Scanner sc=new Scanner(System.in);
		int b=sc.nextInt();
		if(a<=15)
		{
			int s=a/b;
		}
		else
			System.out.println("no exp");
		System.out.println("rgv");
	}

}
