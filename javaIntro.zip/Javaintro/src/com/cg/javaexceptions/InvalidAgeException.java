package com.cg.javaexceptions;

import java.util.Scanner;

public class InvalidAgeException {
 public static void main(String[] args) throws Exception
 {
	Scanner sc=new Scanner(System.in);
	int age=sc.nextInt();
	if(age< 18)
	{
		throw new InvalidAgeException2("age > 18");
	}
	else
		System.out.println("pprocessing");
}
	
}
 class InvalidAgeException2 extends Exception 
 {
	 
	 InvalidAgeException2(String msg)
	 {
		 super(msg);
	 }
	
}
