package com.cg.javaexceptions;

public class SqlTest {

}
