package com.cg.javaexceptions;

import java.util.Scanner;

public class TestEx1 {
	public static void main(String[] args) {
		int a,b,c;
		
		try {
			System.out.println("enter 2 string");
			Scanner sc=new Scanner(System.in);
			a=sc.nextInt();
			b=sc.nextInt();
			c=a/b;
			System.out.println("res "+ c);
		}
		catch(ArithmeticException e)
		{
			System.out.println("do not enter 0");
			
		}
		finally
		{
			System.out.println("finally");
		}
		System.out.println("works this line");
	}
}