package com.cg.string;
import java.util.Scanner;

public class ReplaceChar {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		String temp="";
		for(int i=0;i<str.length();i++)
				{
					char c=str.charAt(i);
					if(c=='A' || c=='E' ||c=='I' ||c=='O' ||c=='U' ||c=='a' ||c=='e' ||c=='i' ||c=='o' ||c=='u' )
					{
						temp=str.replace(c,'X');
						str=temp;
						}
				}
	System.out.println("the ans "+ temp);
	
	}
}
