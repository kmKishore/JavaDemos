package com.cg.string;

import java.util.Scanner;

public class StringFirstTwo {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		StringFirstTwo ob=new StringFirstTwo();
		System.out.println("enter the string");
		String str=sc.nextLine();
		ob.FirstTwo(str);
		ob.F2(str);
		
	}
	
	void FirstTwo(String str)
	{
		String abc="";
		String def="";
		String S2[]=str.split(" ");
		int count=1;
		for(String S3:S2)
		{
			if(count<=2)
				abc=abc+S3+" ";
			else
				def=def+S3+" ";
			count++;
		}
		String ans=def+abc;
		System.out.println("The new string is = " + ans);
	}
	void F2(String str)
	{
		int i=str.indexOf(' ');
		System.out.println(i);
		int j=str.indexOf(' ', i+1);
		System.out.println(j);
		String ans=str.substring(j)+ " "+ str.substring(0,j+1);
		System.out.println("The new string is = " + ans);
	}
}
