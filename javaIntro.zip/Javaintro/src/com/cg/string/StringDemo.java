package com.cg.string;

public class StringDemo {
	public static void main(String args[])
	{
		String s1="hello";
		System.out.println("no of chars " + s1.length());
		System.out.println("Char at 2nd index: "+ s1.charAt(2));
		System.out.println("Concat "+s1.concat(" world"));
		System.out.println("comparing using equals "+ s1.equals("hello"));
		System.out.println("comparing using compareTo "+ s1.compareTo("hello"));
		System.out.println("SubString og beginning index "+ s1.substring(1));
		System.out.println("SubString with beg and end "+ s1.substring(1, 3));
		System.out.println("replace l with h "+ s1.replace('l', 'h'));
	}
}
