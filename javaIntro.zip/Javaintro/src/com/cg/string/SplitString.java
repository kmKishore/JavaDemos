package com.cg.string;

public class SplitString {
	public static void main(String args[])
	{
		String s="hello, good morning";
		String st[]=s.split(" ");
		for(String s2: st)
		{
			System.out.println(s2);
		}
	}
}
