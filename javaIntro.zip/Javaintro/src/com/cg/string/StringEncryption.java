package com.cg.string;

import java.util.Scanner;

public class StringEncryption {
	public static void main(String agrs[])
	{
		StringCheck ob=new StringCheck();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Stirng");
		String Str=sc.nextLine();
		ob.check(Str);
	}

}
class StringCheck
{
	String Str;
	void putVal(String St)
	{
		Str=St;
	}
	void check(String St)
	{
		String abc="";
		for(int i=0;i<St.length();i++)
		{
			int count=0;
			for(int j=i;j<St.length();j++)
			{
				char ch=St.charAt(i);
				String val=""+ ch;
				if(abc.contains(val) && i==j)
					break;
				if(St.charAt(i)==St.charAt(j))
					count++;
				if(i==j)
					abc=abc+St.charAt(i);
				
			}
			if(count!=0)
			System.out.println(St.charAt(i)+" = "+ count);
		}
		
	}
}
