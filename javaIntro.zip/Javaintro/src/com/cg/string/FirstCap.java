package com.cg.string;

import java.util.Scanner;

public class FirstCap {

		public static void main(String args[])
		{
			Scanner sc=new Scanner(System.in);
			String s=sc.nextLine();
			String s2[]=s.split(" ");
			String ans="";
		
			for(String i:s2)
			{
				char c=i.charAt(0);
				String sg=""+c;
				int len=i.length();
				ans=ans+sg.toUpperCase()+i.substring(1,len)+" ";
			}
			System.out.println(ans);
		}
}
