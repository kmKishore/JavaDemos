package com.cg.string;
import java.util.Scanner;

public class CountVowels {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		int temp=0;
		for(int i=0;i<str.length();i++)
				{
					char c=str.charAt(i);
					if(c=='A' || c=='E' ||c=='I' ||c=='O' ||c=='U' ||c=='a' ||c=='e' ||c=='i' ||c=='o' ||c=='u' )
					{
						temp++;
						}
				}
	System.out.println("the ans "+ temp);
	
	}
}