package com.cg.string;

import java.util.Scanner;

public class ReverseString {
	public static void main(String args[])
	{
	
	Scanner sc=new Scanner(System.in);
	String str=sc.next();
	String temp="";
	for(int i=str.length();i>0;i--)
	{
		char val=str.charAt(i-1);
		String s=val+"";
		temp=temp.concat(s);
		
	}
	System.out.println(temp);
	
	}
}