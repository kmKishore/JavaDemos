package com.cg.threads;

public class Reserve implements Runnable {
	int available=1;
	int wanted;
	Reserve(int wanted)
	{
		this.wanted=wanted;
		
	}
	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		String name=Thread.currentThread().getName();
		if(available >=wanted)
		{
			System.out.println(wanted+ " berth(s) allotted to " +  name);
			available=available-wanted;
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
			
			}
		}
		else
		{
			System.out.println("Sorry no seat available");
		}
			
	}
	public static void main(String[] args) 
	{
		
		Reserve r=new Reserve(1);
		Thread t1=new Thread(r);
		t1.setName("mukesh");
		t1.start();
		
		Thread t2=new Thread(r);
		t2.setName("Rakesh");
		t2.start();
	}

}
