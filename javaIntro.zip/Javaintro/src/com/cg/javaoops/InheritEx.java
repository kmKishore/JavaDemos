package com.cg.javaoops;
import java.util.Scanner;
class Person
{
	int Age;
	String Name;
}
class Employee2 extends Person
{
	int Empid;
	String Dept;
	int Salary;
	
	public void putData(int Age,String Name,int Empid,String Dept,int Salary)
	{
		this.Empid=Empid;
		this.Dept=Dept;
		this.Salary=Salary;
		super.Age=Age;
		super.Name=Name;
		
		
	}
	public void getData()
	{
		System.out.println(Name + " " + Age);
		System.out.println(Age);
		System.out.println(Empid);
		System.out.println(Dept);
		System.out.println(Salary);
	}
	
}
class Student extends Person
{
	int RollNo;
	int AvgMarks;
	
}

public class InheritEx {
	public static void main(String agrs[])
	{
		Employee2 emp=new Employee2();
		Scanner sc = new Scanner(System.in);
		/*emp.Age=sc.nextInt();
		emp.Empid=sc.nextInt();
		emp.Salary=sc.nextInt();
		emp.Name=sc.next();
		emp.Dept=sc.next();*/
		emp.putData(30,"akash",06,"cse",12000);
		emp.getData();
		
		
	}
}
