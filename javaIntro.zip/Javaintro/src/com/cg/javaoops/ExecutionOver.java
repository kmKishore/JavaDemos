package com.cg.javaoops;

public class ExecutionOver {
	public static void main(String args[])
	{
		Car ob=new Car();
		ob.fuel();
		Bike ob1=new Bike();
		ob1.fuel();
	}
}
