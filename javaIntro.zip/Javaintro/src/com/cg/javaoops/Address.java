package com.cg.javaoops;

public class Address {
	String Dno,Street,City;
	public Address(String Dno,String Street,String City)
	{
		this.Dno=Dno;
		this.Street=Street;
		this.City=City;
	}
}
