package com.cg.javaoops;

public class Car extends vehicle{

}
