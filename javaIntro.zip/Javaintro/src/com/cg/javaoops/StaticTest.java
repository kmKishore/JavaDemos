package com.cg.javaoops;

public class StaticTest {
	public static void main(String args[])
	{
		StaticEx st=new StaticEx();
		st.method2();
		StaticEx.method1();
	}
}
class StaticEx
{
	public static void method1()
	{
		System.out.println("static");
	}
	public void method2()
	{
		System.out.println("non static");
	}
}
