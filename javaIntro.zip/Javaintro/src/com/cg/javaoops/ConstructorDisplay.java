package com.cg.javaoops;

public class ConstructorDisplay {
	public static void main(String args[])
	{
		B ob=new B(10,"Akash",12000.0f);
		
	}
}
class B
{
	int num;
	String name;
	float sal;
	B(int num,String name,float sal)
	{
		this();
		this.num=num;
		this.name=name;
		this.sal=sal;
		display();
	}
	B()
	{
		System.out.println("default");
	}
	
	void display()
	{
		System.out.println(num);
		System.out.println(name);
		System.out.println(sal);
	}
}