package com.cg.javaoops;

public class Hospital {
	String Name;
	Address addr;
	
	public Hospital(String Name, Address addr)
	{
		this.Name=Name;
		this.addr=addr;
	}
	void display()
	{
		System.out.println("Hospital Name.."+Name);
		System.out.println("Address.");
		System.out.println("Door no."+addr.Dno);
		System.out.println("Street.."+addr.Street);
		System.out.println("City.."+addr.City);
	}
	public static void main(String args[])
	{
		Address add1=new Address("123","Landmark tower","Hyderabad");
		Hospital h=new Hospital("Landmark Hospital",add1);
		h.display();
	}
}
