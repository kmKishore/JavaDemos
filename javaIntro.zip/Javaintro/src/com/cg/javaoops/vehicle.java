package com.cg.javaoops;

public class vehicle {
	void fuel()
	{
		System.out.println("diesel");
	}
}
