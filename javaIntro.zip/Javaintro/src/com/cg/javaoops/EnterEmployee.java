package com.cg.javaoops;
import java.util.Scanner;
public class EnterEmployee {
	public static void main(String args[])
	{
		Employee e= new Employee();
		Scanner sc=new Scanner(System.in);
		String Name=sc.next();
		int age=sc.nextInt();
		e.setAge(age);
		e.setName(Name);
		System.out.println(e.getName());
		System.out.println(e.getAge());
		sc.close();
		
	}
}
