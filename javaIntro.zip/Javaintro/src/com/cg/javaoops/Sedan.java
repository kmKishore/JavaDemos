package com.cg.javaoops;

public class Sedan extends Car{
	

}
