package com.cg.javaoops;

public class InitClass {
	public static void main(String args[])
	{
		TestStudent ic=new TestStudent(10,"Akash");
		
		new TestStudent(11,"Jharna",20);
	}
	

}
class TestStudent
{
	int id;
	String Name;
	TestStudent(int i,String n)
	{
		id=i;
		Name=n;
		showVal();
	}
	TestStudent(int i,String n,int age)
	{
		id=i;
		Name=n;
		showVal();
		System.out.println(age);
	}
	void showVal()
	{
		System.out.println(id);
		System.out.println(Name);
	}
	
}
