package com.cg.javaoops;

public class Coupe {
	final int speed=90;
	void display()
	{
		System.out.println("The max spped "+ speed);
		
	}
	public static void main(String args[])
	{
		Coupe c=new Coupe();
		//c.speed=120; cannot be done
		c.display();
		
	}
}
