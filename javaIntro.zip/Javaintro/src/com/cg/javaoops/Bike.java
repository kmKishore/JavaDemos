package com.cg.javaoops;

public class Bike extends vehicle{
	void fuel()
	{
		System.out.println("petrol");
	}
}
