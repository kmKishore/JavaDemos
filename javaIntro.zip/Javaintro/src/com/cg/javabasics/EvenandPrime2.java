package com.cg.javabasics;

import java.util.Scanner;

class PrintVal2
{
	void method1(String str,int val)
	{
		switch(val)
		{
		case 0:System.out.println(str);
				break;
			
		case 1:System.out.println("not "+str);
				break;
		}
	}
}

public class EvenandPrime2 {
	public static void main(String agrs[])
	{
		int checkVal,checkVal2;
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		EvenandPrime2 obj=new EvenandPrime2();
		checkVal=obj.checkEven(num);
		Prime opj=new Prime();
		checkVal2=opj.checkPrime(num);
		
		
		PrintVal2 obj2=new PrintVal2();
		obj2.method1("Even", checkVal);
		obj2.method1("Prime", checkVal2);
		sc.close();
		
	}
	int checkEven(int num)
	{
		if(num%2==0)
			return 0;
		else
			return 1;
		
	}
	
}

class Prime
{
	int checkPrime(int num)
	{
		int i=1;
		int count=0;
		while(i<num)
		{
			if(num%i==0)
				count++;
			i++;
				
		}
		if(count>1)
			return 1;
		else
			return 0;
	}
}

