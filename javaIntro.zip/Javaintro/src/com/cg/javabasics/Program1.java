package com.cg.javabasics;

public class Program1 {
	public static void main(String args[])
	{
		System.out.println("hello All...");
	}
}
