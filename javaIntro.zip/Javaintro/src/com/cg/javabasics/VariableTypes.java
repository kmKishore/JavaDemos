package com.cg.javabasics;

public class VariableTypes {
	int i =10;
	static int j=20;
	void method1()
	{
		int k = 30;
		System.out.println(k);
		System.out.println(i);
		System.out.println(j);
		j=100;
	}
	void method2()
	{
		
		
		System.out.println(i);
		System.out.println(j);
		
	}
	
	public static void main(String args[])
	{
		VariableTypes vt=new VariableTypes();
		vt.method1();
		vt.method2();
		
		VariableTypes vt2=new VariableTypes();
		vt2.method1();
		vt2.method2();
	}

}
