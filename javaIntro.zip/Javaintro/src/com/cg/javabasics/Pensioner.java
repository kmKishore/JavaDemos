package com.cg.javabasics;

import java.util.Scanner;

public class Pensioner {
	void CalculatePension(double salary, int age)
	{
		if(age>60)
		{
			double amt=(age * salary)/100;
			System.out.println(amt);
		}
		else
		{
			System.out.println("not applicable");
		}
	}
	public static void main(String args[])
	{
		Pensioner obj=new Pensioner();
		Scanner sc =new Scanner(System.in);
		int  age=sc.nextInt();
		double salary=sc.nextDouble();
		obj.CalculatePension(salary, age);
		sc.close();
	}

}
