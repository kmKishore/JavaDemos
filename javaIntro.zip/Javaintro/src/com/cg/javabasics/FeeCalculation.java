package com.cg.javabasics;

import java.util.Scanner;
public class FeeCalculation {
	static Scanner sc=new Scanner(System.in);
	public static void main(String args[]) 
	{
	
		
		double totalfee=0.0;
		System.out.println("enter the type");
		String str=sc.next();
		System.out.println("enter the tution fee");
		int tutionfee=sc.nextInt();
		
		FeeCalculation ob=new FeeCalculation();
		if(str.equals("MSDS"))
		{
			System.out.println("enter the bus fee");
			int busfee=sc.nextInt();
			totalfee=ob.msds(tutionfee,busfee,"MSDS");
		}
		else if (str.equals("MSH"))
		{	
			System.out.println("enter the hostel fee");
			int hostelfee=sc.nextInt();
			totalfee=ob.msh(tutionfee,hostelfee,"MSH");
		}
		else if(str.equals("MGSDS"))
		{	
			System.out.println("enter the bus fee");
			int busfee2=sc.nextInt();
			totalfee=ob.msds(tutionfee,busfee2,"MGSDS");
		}
		else if(str.equals("MGSH"))
		{
			System.out.println("enter the hostel fee");
			int hostelfee2=sc.nextInt();
			totalfee=ob.msh(tutionfee,hostelfee2,"MGSH");
		}
		else
		{
			System.out.println("wrong input");
		}
		System.out.print("the total fee ");
		System.out.println(totalfee);
	}
	double msds(int tutionfee,int busfee,String str)
	{
		if(str.equals("MSDS"))
				return tutionfee + busfee;
		else
			return ((1.5*tutionfee)+busfee);
	}
	double msh(int tutionfee,int hostelfee,String str)
	{
		if(str.equals("MSH"))
			return tutionfee + hostelfee;
		else
			return ((1.5*tutionfee)+hostelfee);
	}

}
