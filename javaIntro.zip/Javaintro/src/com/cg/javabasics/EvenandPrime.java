package com.cg.javabasics;

import java.util.Scanner;

class PrintVal
{
	void method1(String str,int val)
	{
		switch(val)
		{
		case 0:System.out.println(str);
				break;
			
		case 1:System.out.println("not "+str);
				break;
		}
	}
}

public class EvenandPrime {
	public static void main(String agrs[])
	{
		int checkVal,checkVal2;
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		EvenandPrime obj=new EvenandPrime();
		checkVal=obj.checkEven(num);
		checkVal2=obj.checkPrime(num);
		
		
		PrintVal obj2=new PrintVal();
		obj2.method1("Even", checkVal);
		obj2.method1("Prime", checkVal2);
		sc.close();
		
	}
	int checkEven(int num)
	{
		if(num%2==0)
			return 0;
		else
			return 1;
		
	}
	int checkPrime(int num)
	{
		int i=1;
		int count=0;
		while(i<num)
		{
			if(num%i==0)
				count++;
			i++;
				
		}
		if(count>1)
			return 1;
		else
			return 0;
	}
}
