package com.cg.javabasics;

import java.util.Scanner;

public class Maths {
	int x;
	int y;
	void add(int a,int b)
	{	
		int x=a;
		int y=b;
		System.out.println(x+y);
		
	}
	void sub(int a,int b)
	{	
		int x=a;
		int y=b;
		System.out.println(x-y);
		
		
	}
	void mull(int a,int b)
	{
		int x=a;
		int y=b;
		System.out.println(x*y);
		
		
	}
	void div(int a,int b)
	{
		int x=a;
		int y=b;
		System.out.println(x/y);
		
	}
	public static void main(String args[])
	{
		Maths vt=new Maths();
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		vt.add(a,b);
		a=sc.nextInt();
		b=sc.nextInt();
		vt.sub(a,b);
		a=sc.nextInt();
		b=sc.nextInt();
		vt.mull(a,b);
		a=sc.nextInt();
		b=sc.nextInt();
		vt.div(a,b);
		sc.close();
		
	}
}
