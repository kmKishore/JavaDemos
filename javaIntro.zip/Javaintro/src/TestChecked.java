import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class TestChecked {
	
void readfile() throws FileNotFoundException
{
	FileInputStream fis=new FileInputStream("");
	//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	//br.readLine();
}
public static void main(String[] args) throws FileNotFoundException {
	
	TestChecked ce=new TestChecked();
	ce.readfile();
}
}
